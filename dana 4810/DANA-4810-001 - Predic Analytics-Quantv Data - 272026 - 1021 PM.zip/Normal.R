mosaic::xpnorm(65,68,2.5)
library(mosaic)
xpnorm(c(-1.96,1.96))
xqnorm(c(-4.0303,4.0303))
xpt(3.1692,lower.tail = FALSE)
xpt(3.1692,19, lower.tail = FALSE)
###
xcnorm(.9)

###F_DIS
xpf(1.18,11,9)


