#read data
exam <- read.csv("~/Desktop/exam.csv", header = TRUE)

#view the data without showing the first column
head(exam[-1])

#univariate 
boxplot(exam$score)
boxplot(exam$hours)
boxplot(exam$prep)
boxplot(exam$grade)

#calculate the Mahalanobis distance for each observation
#mahalanobis function has 3 arguments: (x, center, cov)
#where x: matrix
#where center: mean vector of the distribution
#where cov: covariance matrix of the distribution

#calculate Mahalanobis distance for each observation
mahalanobis(exam[,-1], colMeans(exam[-1]), cov(exam[-1]))
#the result shows that some Mahalanobis distances are much larger than others
#we need to see if the stances are statistically significant

#create new column in data frame to hold Mahalanobis distances
exam$mahal <- mahalanobis(exam[-1], colMeans(exam[-1]), cov(exam[-1]))

View(exam)
#create new column in data frame to hold p-value for each Mahalanobis distance
#p-value for each distance is calculated as the p-value that corresponds to the Chi-Square statistic of the Mahalanobis distance with k-1 degrees of freedom
#k = a number of variables
exam$p <- pchisq(exam$mahal, df=3, lower.tail=FALSE)
exam

#results: outliers are those with a chi-square typically p-value that is less than .001
#We can see that the first observation is an outlier in the dataset because it has a p-value less than .001

cutoff = qchisq(1-.001, ncol(exam[ , -1]))
cutoff

#do we need to standardize the data when we use Mahalanobis distance
#Mahalanobis distance computation uses inverse of the co-variance matrix while computing the distance which normalizes the original data by the variance and co-variance present in the original data hence there is not at all need to do the same prior to the distance computation.

eu <- dist(exam[-1], method = 'euclidean')
class(eu) #distance matrix
eu
